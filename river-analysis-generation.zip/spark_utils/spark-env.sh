export SCALA_HOME=~/Downloads/spark-1.6.1
export SPARK_WORKER_CORES=1
export SPARK_WORKER_MEMORY=2g
export SPARK_WORKER_INSTANCES=2

# executors are per worker 
export SPARK_EXECUTOR_INSTANCES=1
export SPARK_EXECUTOR_CORES=1
#export SPARK_EXECUTOR_MEMORY=512M
export SPARK_EXECUTOR_MEMORY=2g

export SPARK_WORKER_DIR=~/Downloads/sparkdata
