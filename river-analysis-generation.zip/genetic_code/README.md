### Run on Spark with dummy data 

    $ ./run_example
     
### Run probabilities 

    $ python probabilities.py 


